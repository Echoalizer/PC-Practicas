package model;

import utils.Entero;

public class Hilo extends Thread {
	/*  id
	 *  1 -> Aumentar
	 *  0 -> Disminuir
	 */
	
	private int _id;
	private Entero _num;
	private int _numOper;
	
	public Hilo(int id, Entero num, int numOper) {
		_id = id;
		_num = num;
		_numOper = numOper;
	}
	
	
	@Override
	public void run() {
		
		if(_id == 0) {
			for(int i = 0; i < _numOper;i++)
				_num.decrementar();
		}
		else {
			for(int i = 0; i < _numOper;i++)
				_num.incrementar();
		}
		
	}
}
