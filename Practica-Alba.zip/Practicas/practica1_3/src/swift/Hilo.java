package swift;

public class Hilo extends Thread {
	
	private double[][] _A;
	private double[][] _B;
	private double[][] _C;
	private int _longitud;
	private int _fila;
	
	
	public Hilo(double[][] A, double[][] B, double[][] C, int longitud, int fila) {
		_A = A;
		_B = B;
		_C = C;
		_longitud = longitud;
		_fila = fila;
	}
 	
	
	@Override
	public void run() {
		double suma = 0;
		
		for(int i = 0; i < _longitud;i++) {
			for(int j = 0; j < _longitud;j++) {
				suma += _A[_fila][j] * _B[j][i]; 
			}
			
			_C[_fila][i] = suma;
			suma = 0;
		}
	}
}
