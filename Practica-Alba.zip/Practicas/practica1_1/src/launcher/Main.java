package launcher;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import model.Hilo;

/* ---OBJETIVOS---
 * 1. Saber crear hilos
 * 2. Aprender a hacer un join
 * 3. Darle a cada hilo un id y tiempo de espera
 */


public class Main {

	private static final int TIMELIMIT = 1000; 
	
	public static void main(String[] args) {
		//Vamos a necesitar leer por consola la cantidad de hilos que vamos a crear
		Scanner scan = new Scanner(System.in);
		int numHilos;
		
		//Ahora imprimiremos por consola un mensaje para que el usuario introduza un numero que 
		//correspondera con el numero de hilos a crear
		System.out.print("Introducir número de hilos a crear ");
		//Coge la cadena introducida y la castea a int. Si no es posible -> ERROR
		numHilos = scan.nextInt();
		scan.close(); //Ya no vamos a leer mas asi que cerramos el scanner
		
		
		//Vamos a hacer una lista de procesos.
		List<Hilo> lista = new ArrayList<Hilo>();
		Random rand = new Random(); // Usaremos la variable para asignar a cada proceso un numero entre 0 y timelimit
		
		for(int i = 0; i < numHilos; i++) {
			int time = rand.nextInt(TIMELIMIT);
			Hilo hilo = new Hilo(i,time);
			
			hilo.start();
			lista.add(hilo);
			
		}
		
		for(Hilo h:lista) {
			try {
				h.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}

}

