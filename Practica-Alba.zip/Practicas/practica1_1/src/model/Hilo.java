package model;

public class Hilo extends Thread {
	private int _id;
	private int _time;
	
	public Hilo(int id, int time) {
		_id = id;
		_time = time;
	}
	
	
	@Override
	public void run() {
		System.out.println("El id es " + _id + " y su tiempo es " + _time);
		
		try {
			Thread.sleep(_time);
			System.out.println(_id);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
